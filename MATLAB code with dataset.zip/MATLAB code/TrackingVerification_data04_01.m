function [fout,TR,peak1,peak2,peak3] = TrackingVerification_data04_01(iter,e_3,lastf,i,Noises,TR,pkno1)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
% if e_3(1)>60 && e_3(1)<210
%     fout=e_3(1);
% elseif iter>1
%     fout=lastf;
% else fout=e_3(2);
% end
fout=e_3(1);
peak1=e_3(1);
peak2=e_3(2);
peak3=e_3(3);
if iter>1 
    nos_tol=3;
    if sum(abs(e_3(1)-Noises)<nos_tol) && e_3(1)>60 && e_3(1)<210
        if sum(abs(e_3(2)-Noises)<nos_tol) && e_3(2)>60 && e_3(2)<210
            if sum(abs(e_3(3)-Noises)<nos_tol) && e_3(3)>60 && e_3(3)<210
                e_3(3)=e_3(2);
                e_3(2)=e_3(1);
                e_3(1)=0;
            else
                tmp=e_3(3);
                e_3(3)=e_3(2);
                e_3(2)=e_3(1);
                e_3(1)=tmp;
            end
        else
            tmp=e_3(1);
            e_3(1)=e_3(2);
            e_3(2)=tmp;
            
        end
    end
    
    
    
    
    
    hvr_tol=15;
    
    peak1=e_3(1);
    peak2=e_3(2);
    peak3=e_3(3);
    
    %% SS after swapping pks priority then the nearest pks of last BPM is set as HR for further investigation
    %%
    
        [vval,vvin]=min(abs(e_3-lastf(i-1 )));
        if vval<15
%             disp('check1_nearest')
            fout=e_3(vvin);
        elseif e_3(1)~=0
%             disp('check2_e_3')
            fout=e_3(1);
        else
%           disp('check3_lastf')

            fout=lastf(i-1);
        end
    %% Resolving the pks priority and their relevance
    
  
        fp1_tol=15;
    
    prop_detec=0;
    if abs(fout-lastf(i-1))>fp1_tol || fout<60 || fout>200
        fout=lastf(i-1);
        prop_detec=0;
    elseif vvin==1
        prop_detec=1;

    elseif abs(fout-lastf(i-1))>15
               disp('jhamela_lastf')

        prop_detec=0;
        fout=lastf(i-1);
    end
    
    beta=.8;
    if iter>2
        TR(i)=beta*(fout-lastf(i-1))+(1-beta)*(TR(i-1)-TR(i-2));
    else
        TR(i)=0;
    end
    
    %% Using trends and other condition for accurate HR
    %%
    
    if iter>1 
        if TR(i-1)==0
            if abs( fout-lastf(i-1))>hvr_tol
                disp('5 add kora')
                fout=lastf(i-1)+10*sign(fout-lastf(i-1));
            end
        else
            
            if abs( fout-lastf(i-1))>abs(2*TR(i-1)) && abs( fout-lastf(i-1))>5
                                disp('TR add kora');

                fout=lastf(i-1)+TR(i);
%             elseif abs( fout-lastf(i-1))<abs(2*TR(i-1)) || abs( fout-lastf(i-1))<5
%                 fout=fout;
                
%             else abs( fout-lastf(i-1))>2*hvr_tol
%                 
%                 fout=lastf(i-1);
%                 prop_detec=0;
            end
        end
    end
    
    %% if three consecutive 1st pks are found very close then HR will go there
    %%
    pkno1(i)=peak1;
    no_of_ip=4;
    if fout~=e_3(1) && iter>no_of_ip && prop_detec~=1
        pkk=pkno1(i-no_of_ip+1:i);
        yyy=(pkk==0);
        pkk;
        corrr=corr([1:length(pkk)]',pkk');
        if sum(yyy)==0 && std(abs(diff(pkk)))<3 && mean(abs(diff(pkk)))<5 ...
                && e_3(1)< lastf(i-1)*1.9 && e_3(1)> lastf(i-1)*.7

            if  (min(abs(lastf(i-1)-Noises))<nos_tol) && (min(abs(fout-Noises))<5)
                disp('Jump')
                [ i]
                fout=e_3(1);
                TR(1:i)=zeros(1,i);
            elseif (min(abs(fout-Noises))<5) && prop_detec==2
                fout=e_3(1);
                TR(1:i)=zeros(1,i);
                disp('modified jumped')
            elseif prop_detec==0
                disp('Jump2')
                [ i]
                fout=e_3(1);
                TR(1:i)=zeros(1,i);
            end
        end
    end
else TR(1:i)=zeros(1,i);
end



end

